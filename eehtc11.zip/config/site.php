<?php

return [

    'c_page' => 'home',

];
