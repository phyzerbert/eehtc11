<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <meta charset="utf-8">
        <title>kayne</title>
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700,800,900" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Josefin+Sans%7CQuestrial" rel="stylesheet">
    </head>
    <body style="background:#dedede;">
        <center>
            <table>
                <tr>
                    <td height="20"></td>
                </tr>
            </table>
        <table border="0" cellspacing="0" cellpadding="0" width="600" style="width:6.25in;border-collapse:collapse;background:#FFFFFF;">
            <tbody>
                <tr>
                    <td>
                        <table border="0" cellpadding="0" cellspacing="0" width="100%" align="center" style="background-color:#FFFFFF;">
                            <tr>
                                <td style="text-align:center;">
                                    <p style="font-family:Montserrat, sans-serif;font-size:36px;color:#93BFBA;font-weight:600;text-decoration:none;margin-top:74px;margin-bottom:0px;">NEW-HORIZON</p>
                                </td>
                            </tr>
                        </table>
                    </td>
                    </tr>
                    <tr>
                        <td height="50">
                        </td>
                    </tr>
                    <tr>
                        <td height="4" style="background:#ff7a47;"></td>
                    </tr>
                    <tr>
                        <td style="background-color:#2c6064;padding:.2in .3in .2in .3in;">
                        <p style="text-align:left;color:#FFFFFF;font-size:16pt;margin:0px;padding:.1in .15in .1in .15in;line-height:25px;font-family:Questrial, sans-serif;font-weight:300;">
                            Hi,
                        </p>

                        <p style="text-align:justify;color:#FFFFFF;font-size:12pt;margin:0px;padding:.1in .15in .1in .15in;line-height:25px;font-family:Questrial, sans-serif;font-weight:300;">
                            {{ $content }}
                        </p>
                        <p style="text-align:left;color:#FFFFFF;font-size:16pt;margin:0px;padding:.1in .15in .1in .15in;line-height:25px;font-family:Questrial, sans-serif;font-weight:300;">
                            Sincerely,
                        </p>
                        </td>
                    </tr>
                    <tr>
                        <td height="4" style="background:#ff7a47;"></td>
                    </tr>
                    <tr>
                        <td height="50"></td>
                    </tr>
                    <tr>
                        <td>
                            <table border="0" cellpadding="0" cellspacing="0" width="100%" align="center" style="background-color:#FFFFFF;">
                                <tr>
                                    <td width="200">
                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" align="center" style="background-color:#FFFFFF;">
                                            <tr>
                                                <td align="center">
                                                    <img width="120" src="http://new.eehtc.sa/images/eehtc1.png" alt="">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td align="center"></td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td width="200">
                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" align="center" style="background-color:#FFFFFF;">
                                            <tr>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td align="center">
                                                    <img width="120" src="http://new.eehtc.sa/images/eehtc2.png" alt="">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td align="center"></td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td width="200">
                                        <table border="0" cellpadding="0" cellspacing="0" width="100%" align="center" style="background-color:#FFFFFF;">
                                            <tr>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td align="center">
                                                    <img width="120" src="http://new.eehtc.sa/images/eehtc3.png" alt="">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td align="center"></td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td height="50"></td>
                    </tr>
                    <tr>
                        <td align="center">
                            <table border="0" cellpadding="0" cellspacing="0" width="100%" align="center" style="background-color:#FFFFFF;">
                                <tr>
                                    <td align="center" style="padding:0in .5in;">
                                        <a style="text-decoration:none;" href="http://new.eehtc.sa">
                                            <span style="font-family:'Montserrat', sans-serif; font-size: 22px; color: #FFAD46;font-weight:600; text-decoration: none;margin-top:10px;margin-bottom:0px;">new.eehtc.sa</span>
                                        </a>
                                        <span style="font-family:'Montserrat', sans-serif; font-size: 18px; color: #2c6064;font-weight:600; text-decoration: none;margin-top:10px;margin-bottom:0px;">                                              
                                            1800 Avenue of the Stars, 2nd Floor Los Angeles, California 90067 T 800.231.7414
                                        </span>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td height="40"></td>
                    </tr>
                </tbody>
            </table>
        </center>
    </body>
</html>