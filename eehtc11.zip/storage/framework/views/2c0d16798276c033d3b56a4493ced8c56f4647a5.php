<!DOCTYPE html>
<html lang="en" dir="rtl">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <!-- GLOBAL MAINLY STYLES-->
    <link rel="stylesheet" href="<?php echo e(asset('master/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('master/css/main.css')); ?>">
    <style>
        body { font-family: 'Cairo'; }
    </style>
</head>

<body style="background-color: white;">
    <div class="page-content fade-in-up">
        <div class="ibox">
            <div class="ibox-body">
                <div class="ibox-fullwidth-block py-5">
                    <table width="100%" style="width:100%" border="0">
                        <tbody>
                            <tr>
                                <td>
                                    <h1><?php echo e(config('app.name')); ?></h1>
                                </td>
                                <td class="text-right">
                                    <p class="m-0 py-2">Requested Date: <?php echo e(date('Y-m-d', strtotime($item->created_at))); ?></p>
                                    <p class="m-0 py-2">Invoice Date: <?php echo e(date('Y-m-d')); ?></p>
                                    <p class="m-0 py-2">Email: <?php if(isset($item->user->email)): ?><?php echo e($item->user->email); ?><?php endif; ?></p>
                                    <p class="m-0 py-2">Name: <?php if(isset($item->user->name)): ?><?php echo e($item->user->name); ?><?php endif; ?></p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="ibox-fullwidth-block">
                    <table class="table mb-4">
                        <thead class="thead-default thead-lg">
                            <tr>
                                <th class="pl-4">Company</th>
                                <th>Project</th>
                                <th>Course</th>
                                <th class="text-right pr-4">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="pl-4"><?php if(isset($item->course->project->id)): ?><?php echo e($item->course->project->company->name); ?><?php endif; ?></td>
                                <td><?php if(isset($item->course->project)): ?><?php echo e($item->course->project->name); ?><?php endif; ?></td>
                                <td><?php if(isset($item->course->name)): ?><?php echo e($item->course->name); ?><?php endif; ?></td>
                                <td class="text-right pr-4"><?php echo e($item->amount); ?></td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="4"></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH E:\TITAN\eehtc11\resources\views/project/invoice.blade.php ENDPATH**/ ?>