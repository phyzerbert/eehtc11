<footer class="page-footer">
    <div class="font-13">2019 © <b>نظام إدارة مشروعات شركة أفق</b></div>
    <div>
        <a class="px-3 pl-4" href="http://ingaz.net" target="_blank">Programing By ingaz</a>
    </div>
    <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
</footer><?php /**PATH E:\TITAN\eehtc11\resources\views/layouts/footer.blade.php ENDPATH**/ ?>